package com.example.gpa;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;





import android.os.Bundle;



public class MainActivity extends AppCompatActivity {

    // Variable Declaration

    Button b_calc;

    // Fields that user will input data into

    EditText tn_1, tn_2, tn_3, tn_4, tn_5;

    // Variables used to calculate Grade

    int num1, num2, num3, num4, num5;

    // Variable used to display the GPA

    TextView gpa_display;

    // Variable used to hold the calculation's value

    int calculation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declaring EditText fields

        tn_1 = (EditText) findViewById(R.id.tn_1);
        tn_2 = (EditText) findViewById(R.id.tn_2);
        tn_3 = (EditText) findViewById(R.id.tn_3);
        tn_4 = (EditText) findViewById(R.id.tn_4);
        tn_5 = (EditText) findViewById(R.id.tn_5);

        // Declaring Calculation button

        b_calc = (Button) findViewById(R.id.b_calc);


        restart(b_calc);


    }

    // ********* Calculations *********** \\

public void restart(final Button redo ){

    final LinearLayout backgroundcolor = (LinearLayout) findViewById(R.id.backer); // Gives a varible to control the background with

    // When the calulation button is pressed..

    b_calc.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View x) {

            // Error Validation

            if(tn_1.length() == 0)
            {
                tn_1.setError("Enter A grade");
            }else if(tn_2.length() == 0)
            {
            tn_2.setError("Enter A Grade.");
            }else if(tn_3.length() == 0) {
                tn_3.setError("Enter A Grade.");
            }
            else if(tn_4.length() == 0) {
                tn_4.setError("Enter A Grade.");
            }
            else if(tn_5.length() == 0) {
                tn_5.setError("Enter A Grade.");
            }else
                { // If all of the values have been validated, then the values inside of the fields will be the used.
                num1 = Integer.valueOf(tn_1.getText().toString());
                num2 = Integer.valueOf(tn_2.getText().toString());
                num3 = Integer.valueOf(tn_3.getText().toString());
                num4 = Integer.valueOf(tn_4.getText().toString());
                num5 = Integer.valueOf(tn_5.getText().toString());



                calculation = (num1 + num2 + num3 + num4 + num5) / 5;

                gpa_display.setText(String.valueOf(calculation)); // Displays the resulting calulation in the application.

                    // Changing the background color
                if (calculation <= 60) {
                    backgroundcolor.setBackgroundColor(Color.RED);
                } else if (calculation >= 61 && calculation <= 79) {
                    backgroundcolor.setBackgroundColor(Color.YELLOW);
                } else if (calculation >= 80 && calculation <= 100){
                    backgroundcolor.setBackgroundColor(Color.GREEN);

            }
                // When finished calulation, use the same button to clear the form.

                b_calc.setText("Clear");

                if(b_calc.getText() == "Clear"){  // IF the caluclation was done correctly, the button will be set to clear, and the program will trigger off of it.
                    b_calc.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View x) {  // Sets all the starting values to blank.
                            tn_1.setText("");
                            tn_2.setText("");
                            tn_3.setText("");
                            tn_4.setText("");
                            tn_5.setText("");
                            gpa_display.setText("Ready to Calculate");

                            backgroundcolor.setBackgroundColor(Color.WHITE);
                            b_calc.setText("Calculate");

                            if(b_calc.getText() == "Calculate")
                            {
                                restart(redo);
                            }
                        }



                 });


             }



        }
    };

});




}}